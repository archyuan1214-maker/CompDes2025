
# import Rhino.Geometry as rg

# def GetmeshCentroidpt(mesh):
#     vertices = mesh.Vertices
#     faces=mesh.Faces
#     number_faces=faces.Count
#     centroid_points=[]
#     for i in range(number_faces):
#         iface=faces[i]
#         iface_vertices_num=iface.Vertices.Count
#         iface_vertices=iface.GetVertices()
#         sum_x=0
#         sum_y=0
#         sum_z=0
#         for j in range(iface_vertices_num):
#             v_iface=iface_vertices[j]
#             sum_x=sum_x+v_iface.X
#             sum_y=sum_y+v_iface.Y
#             sum_z=sum_z+v_iface.Z
#         centroid_x=sum_x/iface_vertices_num
#         centroid_y=sum_y/iface_vertices_num 
#         centroid_z=sum_z/iface_vertices_num
#         centroid_pt=rg.Point3d(centroid_x,centroid_y,centroid_z)
#         centroid_points.append(centroid_pt)
        
#     return centroid_points

# a = GetmeshCentroidpt(imesh)
# print(a)



'''task1'''

import Rhino.Geometry as rg

def mesh_face_centroids(mesh):
    centroids = []
    for i in range(mesh.Faces.Count):
        face = mesh.Faces[i]

        # Extract vertices of the face
        A = mesh.Vertices[face.A]
        B = mesh.Vertices[face.B]
        C = mesh.Vertices[face.C]

        if face.IsQuad:
            D = mesh.Vertices[face.D]
            # Quad centroid = average of 4 points
            x = (A.X + B.X + C.X + D.X) / 4.0
            y = (A.Y + B.Y + C.Y + D.Y) / 4.0
            z = (A.Z + B.Z + C.Z + D.Z) / 4.0
        else:
            # Triangle centroid = average of 3 points
            x = (A.X + B.X + C.X) / 3.0
            y = (A.Y + B.Y + C.Y) / 3.0
            z = (A.Z + B.Z + C.Z) / 3.0

        centroids.append(rg.Point3d(x, y, z))

    return centroids

    
a=mesh_face_centroids(imesh)



'''task2'''
import Rhino.Geometry as rg

def face_area(mesh, face):
    A = mesh.Vertices[face.A]
    B = mesh.Vertices[face.B]
    C = mesh.Vertices[face.C]
    
    v1 = B - A
    v2 = C - A
    cross = rg.Vector3f.CrossProduct(v1, v2)
    area = cross.Length * 0.5
    
    if face.IsQuad:
        D = mesh.Vertices[face.D]
        v3 = D - A
        v4 = C - A
        area += v3.CrossProduct(v4).Length * 0.5
    
    return area

def face_centroid(mesh, face):
    A = mesh.Vertices[face.A]
    B = mesh.Vertices[face.B]
    C = mesh.Vertices[face.C]
    
    if face.IsQuad:
        D = mesh.Vertices[face.D]
        x = (A.X + B.X + C.X + D.X) / 4.0
        y = (A.Y + B.Y + C.Y + D.Y) / 4.0
        z = (A.Z + B.Z + C.Z + D.Z) / 4.0
    else:
        x = (A.X + B.X + C.X) / 3.0
        y = (A.Y + B.Y + C.Y) / 3.0
        z = (A.Z + B.Z + C.Z) / 3.0
    
    return rg.Point3d(x, y, z)

def largest_face_point(mesh):
    max_area = -1.0
    max_face_index = -1
    max_centroid = None
    
    for i in range(mesh.Faces.Count):
        face = mesh.Faces[i]
        area = face_area(mesh, face)
        
        if area > max_area:
            max_area = area
            max_face_index = i
            max_centroid = face_centroid(mesh, face)
    
    return max_face_index, max_area, max_centroid

a,b,c=largest_face_point(imesh)


'''task3'''




import Rhino.Geometry as rg

if mesh is None or attPt is None:
    deformed = None
else:
    # 复制 mesh（避免直接修改输入）
    m = mesh.DuplicateMesh()
    vtx = m.Vertices

    for i in range(vtx.Count):
        p = rg.Point3d(vtx[i])

        # 顶点到吸引点的距离
        d = p.DistanceTo(attPt)

        # 超出作用范围 -> 不移动
        if d > maxDist:
            continue

        # 距离越近，影响越大（线性衰减）
        t = 1.0 - (d / maxDist)   # t ∈ [0,1]

        # 移动方向 = 吸引点 - 原点
        direction = rg.Vector3d(attPt - p)
        direction.Unitize()

        # 位移向量
        move = direction * (strength * t)

        # 设置新顶点位置
        new_p = p + move
        vtx.SetVertex(i, new_p)

    m.Normals.ComputeNormals()
    m.Compact()

    deformed = m



